/* ============================================================
   AutoPush Studio — simple client
   Paste/open a folder, then commit · push · pull. That's it.
   ============================================================ */
(() => {
  "use strict";
  const API = "/api";

  const state = { repo: null, status: null, settings: { theme: "light", saved_repos: [] }, busy: false, draft: "" };
  const activity = [];

  // ---- helpers ----
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const base = (p) => (p ? p.replace(/[\\/]+$/, "").split(/[\\/]/).pop() : "");
  const now = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  async function call(path, body = {}, method = "POST") {
    const opt = { method, headers: { "Content-Type": "application/json" } };
    if (method !== "GET") opt.body = JSON.stringify(body);
    let res;
    try { res = await fetch(API + path, opt); }
    catch { throw { message: "Can't reach the app's engine — is it still running?", code: "offline" }; }
    const data = await res.json().catch(() => ({}));
    if (!data.ok) throw { message: data.error || "Something went wrong", code: data.code || "error" };
    return data.data;
  }

  // ---- toast + activity ----
  function toast(title, msg = "", kind = "info", ttl = 3800) {
    const node = document.createElement("div");
    node.className = `toast ${kind}`;
    const ic = kind === "ok" ? "check" : kind === "err" ? "alert" : "info";
    node.innerHTML = `<span class="ti">${icon(ic, 19)}</span><div><div class="tt">${esc(title)}</div>${msg ? `<div class="tm">${esc(msg)}</div>` : ""}</div>`;
    $("#toastHost").appendChild(node);
    const kill = () => { node.classList.add("leaving"); setTimeout(() => node.remove(), 250); };
    node.onclick = kill; setTimeout(kill, ttl);
  }
  function act(msg, kind = "info") {
    activity.unshift({ t: now(), msg, kind });
    if (activity.length > 30) activity.pop();
    renderActivity();
  }

  // ---- modal ----
  function modal(html) {
    const host = $("#modalHost");
    host.innerHTML = `<div class="modal">${html}</div>`;
    host.hidden = false;
    host.onclick = (e) => { if (e.target === host) closeModal(); };
    host._key = (e) => { if (e.key === "Escape") closeModal(); };
    document.addEventListener("keydown", host._key);
    const inp = host.querySelector("input, textarea");
    if (inp) setTimeout(() => inp.focus(), 60);
  }
  function closeModal() {
    const host = $("#modalHost");
    host.hidden = true; host.innerHTML = "";
    if (host._key) document.removeEventListener("keydown", host._key);
  }
  function confirmBox({ title, message, ok = "OK", danger = false }) {
    return new Promise((res) => {
      modal(`<div class="modal-head"><h3>${icon("alert", 19)} ${esc(title)}</h3><button class="modal-x" id="mx" aria-label="Close">${icon("x", 18)}</button></div>
        <div class="modal-body"><p class="pre">${esc(message)}</p></div>
        <div class="modal-foot"><button class="btn ghost" id="mc">Cancel</button><button class="btn ${danger ? "danger" : "primary"}" id="my">${esc(ok)}</button></div>`);
      $("#my").onclick = () => { closeModal(); res(true); };
      $("#mc").onclick = $("#mx").onclick = () => { closeModal(); res(false); };
    });
  }

  // ---- menu ----
  function menu(rect, items) {
    closeMenu();
    const m = document.createElement("div");
    m.className = "menu"; m.id = "menu";
    m.innerHTML = items.map((it) => it.label && it.head ? `<div class="menu-label">${esc(it.label)}</div>` : it.sep ? `<div class="menu-sep"></div>` : `<button class="menu-item ${it.on ? "on" : ""}">${it.icon ? icon(it.icon, 16) : ""}<span>${esc(it.label)}</span></button>`).join("");
    document.body.appendChild(m);
    let left = Math.min(rect.left, window.innerWidth - m.offsetWidth - 10);
    let top = rect.bottom + 6;
    if (top + m.offsetHeight > window.innerHeight - 10) top = rect.top - m.offsetHeight - 6;
    m.style.left = Math.max(10, left) + "px"; m.style.top = Math.max(10, top) + "px";
    let i = 0;
    items.forEach((it) => { if (it.head || it.sep) return; const b = m.querySelectorAll(".menu-item")[i++]; b.onclick = () => { closeMenu(); it.click && it.click(); }; });
    setTimeout(() => document.addEventListener("click", closeMenu, { once: true }), 0);
  }
  function closeMenu() { const m = $("#menu"); if (m) m.remove(); }

  // ============================================================ render
  function render() {
    $("#main").innerHTML = state.repo ? repoCard() : openCard();
    if (state.repo) {
      const ta = $("#commitMsg");
      if (ta) { ta.value = state.draft; ta.addEventListener("input", () => state.draft = ta.value); }
    } else {
      const inp = $("#pathInput");
      if (inp) inp.addEventListener("keydown", (e) => { if (e.key === "Enter") openRepo(inp.value.trim()); });
    }
  }

  function openCard() {
    const recents = (state.settings.saved_repos || []).slice(0, 6);
    const chips = recents.length ? `<div class="recent"><div class="recent-label">Recent</div><div class="recent-chips">${recents.map((r) => `<button class="recent-chip" data-open="${esc(r.path)}" title="${esc(r.path)}">${icon("folder", 14)}<span>${esc(r.label || base(r.path))}</span><span class="x" data-forget="${esc(r.path)}" title="Remove">${icon("x", 12)}</span></button>`).join("")}</div></div>` : "";
    return `<section class="card open-card"><div class="card-pad">
      <div class="open-title">Open a project</div>
      <div class="open-hint">Paste the folder path of your project, or browse for it.</div>
      <div class="path-row">
        <label class="path-input">${icon("folder", 18)}<input id="pathInput" placeholder="C:\\Users\\you\\my-project" spellcheck="false" /></label>
      </div>
      <div class="btn-grid two">
        <button class="btn soft big" data-act="browse">${icon("folder-open", 18)} Browse…</button>
        <button class="btn primary big" data-act="open">${icon("chevron-right", 18)} Open</button>
      </div>
      ${chips}
    </div></section>`;
  }

  function repoCard() {
    const s = state.status || {};
    const conflicts = s.conflicted || [];
    const changes = [...(s.staged || []), ...(s.unstaged || []), ...(s.untracked || [])];
    // de-dupe by path (a file can be staged + unstaged)
    const seen = new Set(); const list = [];
    [...conflicts, ...changes].forEach((f) => { if (!seen.has(f.path)) { seen.add(f.path); list.push(f); } });
    const ahead = s.ahead || 0, behind = s.behind || 0;
    const merging = s.state === "merging" || s.state === "rebasing";

    let banner, bcls;
    if (conflicts.length) { bcls = "conflict"; banner = `${icon("alert", 17)} ${conflicts.length} conflict${conflicts.length > 1 ? "s" : ""} — pick a version for each, then commit`; }
    else if (merging) { bcls = "dirty"; banner = `${icon("merge", 17)} Merge in progress — commit to finish`; }
    else if (list.length) { bcls = "dirty"; banner = `${icon("edit", 17)} ${list.length} change${list.length > 1 ? "s" : ""} ready to commit`; }
    else if (ahead) { bcls = "dirty"; banner = `${icon("push", 17)} ${ahead} commit${ahead > 1 ? "s" : ""} ready to push`; }
    else { bcls = "clean"; banner = `${icon("check", 17)} Everything's up to date`; }

    const sync = `<div class="sync">${behind ? `<span class="sync-tag hot">${icon("down", 13)} ${behind} to pull</span>` : ""}${ahead ? `<span class="sync-tag hot">${icon("up", 13)} ${ahead} to push</span>` : ""}${!ahead && !behind ? `<span class="sync-tag">in sync</span>` : ""}</div>`;

    const rows = list.length ? list.map((f) => changeRow(f)).join("") : `<div class="empty-changes">No changes — your folder matches the last commit.</div>`;

    const canCommit = (s.staged?.length || s.unstaged?.length || s.untracked?.length || merging) && !conflicts.length;
    const commitLabel = merging ? "Finish merge" : "Commit";

    return `<section class="card">
      <div class="repo-top">
        <div class="repo-name">${icon("folder", 18)}<span class="txt" title="${esc(state.repo.path)}">${esc(state.repo.label)}</span></div>
        <button class="branch-btn" data-act="branch">${icon("branch", 14)} ${esc(s.branch || "—")} ${icon("chevron", 13)}</button>
        <span class="repo-spacer"></span>
        <button class="change-folder" data-act="close-repo">change folder</button>
      </div>
      <div class="status-banner ${bcls}">${banner}${sync}</div>
      ${conflicts.length ? `<div class="conflict-bar">${icon("alert", 16)} Resolve all files, then click ${commitLabel}.<button class="btn danger" data-act="abort">${icon("x", 14)} Abort</button></div>` : ""}
      <div class="changes">${rows}</div>
      <div class="commit-zone">
        <textarea id="commitMsg" placeholder="What did you change? (commit message)"></textarea>
        <div class="btn-grid two">
          <button class="btn soft" data-act="commit" ${canCommit ? "" : "disabled"}>${icon("commit", 17)} ${commitLabel}</button>
          <button class="btn primary" data-act="commit-push" ${canCommit ? "" : "disabled"}>${icon("rocket", 17)} ${commitLabel} &amp; Push</button>
        </div>
        <div class="btn-grid three">
          <button class="btn ghost" data-act="push">${icon("push", 16)} Push</button>
          <button class="btn ghost" data-act="pull">${icon("pull", 16)} Pull</button>
          <button class="btn ghost" data-act="fetch">${icon("fetch", 16)} Fetch</button>
        </div>
      </div>
    </section>`;
  }

  function changeRow(f) {
    const st = f.status || "modified";
    const conflict = st === "conflicted";
    const letter = conflict ? "C" : (f.x || f.y || st[0] || "?").toUpperCase().replace("?", "U");
    const tagcls = conflict ? "c" : { M: "m", A: "a", U: "u", D: "d", R: "m", C: "m", T: "m" }[letter] || "m";
    const acts = conflict
      ? `<div class="conflict-acts"><button class="mini-btn" data-ours="${esc(f.path)}">Keep mine</button><button class="mini-btn" data-theirs="${esc(f.path)}">Keep theirs</button></div>`
      : "";
    return `<div class="change-row" ${conflict ? "" : `data-diff="${esc(f.path)}" data-staged="${!!(f.x && f.x !== "?")}"`}>
      <span class="tag ${tagcls}" title="${esc(st)}">${letter}</span>
      <span class="change-name" dir="rtl">${esc(f.path)}</span>${acts}</div>`;
  }

  function renderActivity() {
    $("#activityTitle").innerHTML = `${icon("terminal", 16)} Activity`;
    $("#activityList").innerHTML = activity.length
      ? activity.map((a) => `<div class="act-row ${a.kind}"><span class="at">${a.t}</span><span class="am">${esc(a.msg)}</span></div>`).join("")
      : `<div class="act-empty">Nothing yet. Open a project to get started.</div>`;
  }

  // ============================================================ flows
  async function openRepo(path, remember = true) {
    if (!path) { toast("Enter a folder path", "", "err"); return; }
    let sum;
    try { sum = await call("/repo/open", { path }); }
    catch (e) { toast("Couldn't open that folder", e.message, "err"); return; }
    if (!sum.is_repo) {
      const yes = await confirmBox({ title: "Not a Git project yet", message: `"${base(path)}" isn't set up for Git.\n\nSet it up now so you can commit and push?`, ok: "Set it up" });
      if (!yes) return;
      try { await call("/repo/init", { path }); act(`Set up Git in ${base(path)}`, "ok"); }
      catch (e) { toast("Setup failed", e.message, "err"); return; }
      sum = await call("/repo/open", { path });
    }
    state.repo = { path, label: base(path) };
    state.draft = "";
    if (remember) saveRepo(path);
    act(`Opened ${base(path)}${sum.branch ? " on " + sum.branch : ""}`, "ok");
    await refresh();
  }

  async function refresh() {
    if (!state.repo) return;
    try { state.status = await call("/status", { path: state.repo.path }); }
    catch (e) { toast("Couldn't read status", e.message, "err"); return; }
    render();
  }

  function closeRepo() { state.repo = null; state.status = null; render(); }

  function saveRepo(path) {
    const r = state.settings.saved_repos || [];
    const f = r.filter((x) => x.path !== path);
    f.unshift({ path, label: base(path) });
    state.settings.saved_repos = f.slice(0, 12);
    call("/settings", { saved_repos: state.settings.saved_repos }).catch(() => {});
  }
  function forgetRepo(path) {
    state.settings.saved_repos = (state.settings.saved_repos || []).filter((x) => x.path !== path);
    call("/settings", { saved_repos: state.settings.saved_repos }).catch(() => {});
    render();
  }

  async function busy(fn) {
    if (state.busy) return;
    state.busy = true;
    try { await fn(); } finally { state.busy = false; }
  }

  async function doCommit(push) {
    const msg = ($("#commitMsg")?.value || "").trim();
    const s = state.status || {};
    const merging = s.state === "merging" || s.state === "rebasing";
    const hasChanges = s.staged?.length || s.unstaged?.length || s.untracked?.length;
    if ((s.conflicted || []).length) { toast("Resolve conflicts first", "Pick a version for each file.", "err"); return; }
    if (!hasChanges && !merging) { toast("Nothing to commit", "Make some changes first.", "info"); return; }
    if (!msg) { toast("Add a commit message", "Tell us what changed.", "err"); $("#commitMsg")?.focus(); return; }
    await busy(async () => {
      try {
        if (hasChanges) await call("/stage", { path: state.repo.path, files: "all" });
        await call("/commit", { path: state.repo.path, message: msg, author_name: state.settings.author_name || null, author_email: state.settings.author_email || null, branch: s.branch });
        state.draft = "";
        act(`Committed: ${msg}`, "ok"); toast("Committed", msg, "ok");
        await refresh();
        if (push) await doPush();
      } catch (e) { act(`Commit failed: ${e.message}`, "err"); toast("Commit failed", e.message, "err"); }
    });
  }

  async function doPush(force = false) {
    const s = state.status || {};
    if (!s.has_commits) { toast("Nothing to push yet", "Make your first commit.", "info"); return; }
    await busy(async () => {
      btnSpin('[data-act="push"]', true, "Pushing…");
      try {
        const res = await call("/push", { path: state.repo.path, branch: s.branch, force });
        act(res.message, "ok"); toast("Pushed", res.message, "ok");
        await refresh();
      } catch (e) {
        if (e.code === "noremote") { btnSpin('[data-act="push"]', false); return publishModal(); }
        if (e.code === "rejected") {
          btnSpin('[data-act="push"]', false);
          const f = await confirmBox({ title: "The remote is ahead", message: e.message + "\n\nForce push to overwrite what's on GitHub? This can erase remote work.", ok: "Force push", danger: true });
          if (f) return doPush(true);
          return;
        }
        if (e.code === "auth") { act("Push failed: token needed", "err"); toast("Sign-in needed", "Add your GitHub token in Settings (⚙).", "err", 5500); }
        else { act(`Push failed: ${e.message}`, "err"); toast("Push failed", e.message, "err"); }
      } finally { btnSpin('[data-act="push"]', false); }
    });
  }

  async function doPull() {
    const s = state.status || {};
    await busy(async () => {
      btnSpin('[data-act="pull"]', true, "Pulling…");
      try {
        const res = await call("/pull", { path: state.repo.path, branch: s.branch });
        await refresh();
        if (res.conflict) { act("Pulled — but there are conflicts to resolve", "err"); toast("Conflicts to resolve", "Pick a version for each file below.", "err", 5500); }
        else { act(res.message, "ok"); toast("Pulled", res.message, "ok"); }
      } catch (e) {
        if (e.code === "noremote") { toast("No remote set", "Push/publish first to connect a GitHub repo.", "info"); }
        else if (e.code === "unrelated") {
          const ok = await confirmBox({ title: "Different histories", message: e.message + "\n\nMerge them anyway?", ok: "Merge" });
          if (ok) { try { const r = await call("/pull", { path: state.repo.path, branch: s.branch, allow_unrelated: true }); await refresh(); act(r.conflict ? "Merged with conflicts" : r.message, r.conflict ? "err" : "ok"); } catch (e2) { toast("Pull failed", e2.message, "err"); } }
        } else { act(`Pull failed: ${e.message}`, "err"); toast("Pull failed", e.message, "err"); }
      } finally { btnSpin('[data-act="pull"]', false); }
    });
  }

  async function doFetch() {
    await busy(async () => {
      btnSpin('[data-act="fetch"]', true);
      try { const res = await call("/fetch", { path: state.repo.path }); act(res.message, "ok"); toast("Checked for updates", res.message, "ok"); await refresh(); }
      catch (e) { if (e.code === "noremote") toast("No remote set", "Publish to GitHub first.", "info"); else toast("Fetch failed", e.message, "err"); }
      finally { btnSpin('[data-act="fetch"]', false); }
    });
  }

  function btnSpin(sel, on, label) {
    const b = document.querySelector(sel); if (!b) return;
    if (on) { b._h = b.innerHTML; b.disabled = true; b.innerHTML = `${icon("refresh", 16, "spin")}${label ? " " + label : ""}`; }
    else { b.disabled = false; if (b._h) b.innerHTML = b._h; }
  }

  // conflict resolve
  async function resolve(file, strategy) {
    try { await call("/conflict/resolve", { path: state.repo.path, file, strategy }); act(`Kept ${strategy === "ours" ? "your" : "their"} version of ${base(file)}`, "ok"); await refresh(); }
    catch (e) { toast("Couldn't resolve", e.message, "err"); }
  }
  async function abortMerge() {
    const ok = await confirmBox({ title: "Abort the merge?", message: "Throw away this merge and go back to how things were?", ok: "Abort", danger: true });
    if (!ok) return;
    try { await call("/merge/abort", { path: state.repo.path }); act("Merge aborted", "info"); await refresh(); }
    catch (e) { toast("Couldn't abort", e.message, "err"); }
  }

  // publish (first push)
  function publishModal() {
    modal(`<div class="modal-head"><h3>${icon("rocket", 19)} Publish to GitHub</h3><button class="modal-x" id="mx" aria-label="Close">${icon("x", 18)}</button></div>
      <div class="modal-body">
        <p>Connect this project to a GitHub repository, then push everything up.</p>
        <div class="field"><label>Repository URL</label><input id="pubUrl" placeholder="https://github.com/you/your-repo.git" spellcheck="false" /></div>
        <div class="row-2">
          <div class="field"><label>Branch</label><input id="pubBranch" value="${esc(state.status?.branch || state.settings.default_branch || "main")}" spellcheck="false" /></div>
          <div class="field"><label>Token ${state.settings.has_token ? "(saved)" : ""}</label><input id="pubToken" type="password" placeholder="${state.settings.has_token ? "leave blank — saved" : "ghp_…"}" /></div>
        </div>
        <p class="hint" style="font-size:.78rem;color:var(--text-3)">A token is needed for private repos. Create one at github.com → Settings → Developer settings → Tokens.</p>
      </div>
      <div class="modal-foot"><button class="btn ghost" id="mc">Cancel</button><button class="btn primary" id="pubGo">${icon("rocket", 16)} Publish</button></div>`);
    $("#mc").onclick = $("#mx").onclick = closeModal;
    $("#pubGo").onclick = async () => {
      const url = $("#pubUrl").value.trim(), branch = $("#pubBranch").value.trim() || "main", token = $("#pubToken").value.trim();
      if (!url) { toast("Enter the repo URL", "", "err"); return; }
      const b = $("#pubGo"); b.disabled = true; b.innerHTML = `${icon("refresh", 16, "spin")} Publishing…`;
      try {
        await call("/remote/set", { path: state.repo.path, name: "origin", url });
        const st = await call("/status", { path: state.repo.path });
        if (st.staged.length || st.unstaged.length || st.untracked.length || !st.has_commits) {
          await call("/stage", { path: state.repo.path, files: "all" });
          try { await call("/commit", { path: state.repo.path, message: "Initial commit", branch }); } catch (e) { if (e.code !== "empty") throw e; }
        }
        const res = await call("/push", { path: state.repo.path, branch, token, repo_url: url });
        closeModal(); act(`Published to ${url}`, "ok"); toast("Published 🎉", res.message, "ok"); await refresh();
      } catch (e) { toast("Publish failed", e.message, "err"); b.disabled = false; b.innerHTML = `${icon("rocket", 16)} Publish`; }
    };
  }

  // branch switch
  async function branchMenu(rect) {
    let data;
    try { data = await call("/branches", { path: state.repo.path }); }
    catch (e) { toast("Couldn't load branches", e.message, "err"); return; }
    const items = [{ label: "Switch branch", head: true }];
    data.local.forEach((b) => items.push({ label: b.name, icon: "branch", on: b.current, click: () => !b.current && switchBranch(b.name) }));
    items.push({ sep: true }, { label: "New branch…", icon: "plus", click: newBranch });
    menu(rect, items);
  }
  async function switchBranch(name) {
    try { await call("/branch/checkout", { path: state.repo.path, name }); act(`Switched to ${name}`, "ok"); toast("Switched branch", name, "ok"); await refresh(); }
    catch (e) { toast("Couldn't switch", e.message, "err"); }
  }
  function newBranch() {
    modal(`<div class="modal-head"><h3>${icon("branch", 19)} New branch</h3><button class="modal-x" id="mx" aria-label="Close">${icon("x", 18)}</button></div>
      <div class="modal-body"><div class="field"><label>Branch name</label><input id="nbName" placeholder="my-feature" spellcheck="false" /></div></div>
      <div class="modal-foot"><button class="btn ghost" id="mc">Cancel</button><button class="btn primary" id="nbGo">${icon("plus", 16)} Create</button></div>`);
    $("#mc").onclick = $("#mx").onclick = closeModal;
    $("#nbGo").onclick = async () => {
      const name = $("#nbName").value.trim(); if (!name) { toast("Enter a name", "", "err"); return; }
      try { await call("/branch/create", { path: state.repo.path, name, checkout: true }); closeModal(); act(`Created branch ${name}`, "ok"); toast("Branch created", name, "ok"); await refresh(); }
      catch (e) { toast("Couldn't create", e.message, "err"); }
    };
  }

  // diff preview
  async function showDiff(file, staged) {
    modal(`<div class="modal-head"><h3>${icon("file", 18)} ${esc(base(file))}</h3><button class="modal-x" id="mx" aria-label="Close">${icon("x", 18)}</button></div>
      <div class="modal-body" id="diffBody"><div class="act-empty">${icon("refresh", 16, "spin")} Loading…</div></div>`);
    $("#mx").onclick = closeModal;
    try {
      const d = await call("/diff", { path: state.repo.path, file, staged });
      const body = $("#diffBody"); if (!body) return;
      if (d.binary) { body.innerHTML = `<p>Binary file — no preview.</p>`; return; }
      if (!d.diff) { body.innerHTML = `<p>No changes to show.</p>`; return; }
      const lines = d.diff.split("\n").map((l) => {
        let c = "var(--text-2)", bg = "transparent";
        if (l.startsWith("@@")) { c = "var(--accent)"; }
        else if (l.startsWith("+") && !l.startsWith("+++")) { c = "var(--ok)"; bg = "var(--ok-soft)"; }
        else if (l.startsWith("-") && !l.startsWith("---")) { c = "var(--danger)"; bg = "var(--danger-soft)"; }
        else if (l.startsWith("diff ") || l.startsWith("index ") || l.startsWith("+++") || l.startsWith("---")) { c = "var(--text-3)"; }
        return `<div style="color:${c};background:${bg};padding:0 6px">${esc(l) || "&nbsp;"}</div>`;
      }).join("");
      body.innerHTML = `<div style="font-family:var(--mono);font-size:.8rem;line-height:1.55;overflow:auto;white-space:pre">${lines}</div>`;
    } catch (e) { const body = $("#diffBody"); if (body) body.innerHTML = `<p>${esc(e.message)}</p>`; }
  }

  // settings
  function settingsModal() {
    const s = state.settings;
    modal(`<div class="modal-head"><h3>${icon("settings", 19)} Settings</h3><button class="modal-x" id="mx" aria-label="Close">${icon("x", 18)}</button></div>
      <div class="modal-body">
        <div class="field"><label>GitHub token</label><input id="setToken" type="password" placeholder="${s.has_token ? "•••••• saved — leave blank to keep" : "ghp_…"}" /><span class="hint">Needed for private repos. Stored only on this PC.</span></div>
        <div class="toggle"><div class="tx"><strong>Remember token</strong><span>Keep it saved on this computer.</span></div><label class="switch"><input type="checkbox" id="setRemember" ${s.remember_token ? "checked" : ""}><span class="slider"></span></label></div>
        <div class="row-2">
          <div class="field"><label>Your name</label><input id="setName" value="${esc(s.author_name || "")}" placeholder="Your Name" /></div>
          <div class="field"><label>Your email</label><input id="setEmail" value="${esc(s.author_email || "")}" placeholder="you@example.com" /></div>
        </div>
        <div class="field"><label>Default branch</label><input id="setBranch" value="${esc(s.default_branch || "main")}" /></div>
        <div class="toggle"><div class="tx"><strong>Dark mode</strong><span>Easy on the eyes.</span></div><label class="switch"><input type="checkbox" id="setDark" ${s.theme === "dark" ? "checked" : ""}><span class="slider"></span></label></div>
      </div>
      <div class="modal-foot"><button class="btn ghost" id="mc">Cancel</button><button class="btn primary" id="setGo">${icon("check", 16)} Save</button></div>`);
    $("#mc").onclick = $("#mx").onclick = closeModal;
    $("#setGo").onclick = async () => {
      const patch = { token: $("#setToken").value.trim(), remember_token: $("#setRemember").checked, author_name: $("#setName").value.trim(), author_email: $("#setEmail").value.trim(), default_branch: $("#setBranch").value.trim() || "main", theme: $("#setDark").checked ? "dark" : "light" };
      try { state.settings = await call("/settings", patch); applyTheme(state.settings.theme); closeModal(); toast("Saved", "Settings updated.", "ok"); }
      catch (e) { toast("Couldn't save", e.message, "err"); }
    };
  }

  // theme
  function applyTheme(t) {
    const el = document.documentElement;
    el.classList.add("theme-switching");
    el.setAttribute("data-theme", t === "dark" ? "dark" : "light");
    void document.body.offsetHeight;
    requestAnimationFrame(() => el.classList.remove("theme-switching"));
    $("#themeBtn").innerHTML = icon(t === "dark" ? "sun" : "moon", 18);
  }
  function toggleTheme() {
    const t = state.settings.theme === "dark" ? "light" : "dark";
    state.settings.theme = t; applyTheme(t);
    call("/settings", { theme: t }).catch(() => {});
  }

  async function pickFolder() {
    try { const r = await call("/pick-folder", {}); return r.path || null; }
    catch (e) { if (e.code === "nopicker") return prompt("Type or paste the full folder path:") || null; toast("Picker failed", e.message, "err"); return null; }
  }

  // ============================================================ events
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-act],[data-open],[data-forget],[data-diff],[data-ours],[data-theirs]");
    if (!t) return;
    if (t.dataset.forget !== undefined) { e.stopPropagation(); return forgetRepo(t.dataset.forget); }
    if (t.dataset.open !== undefined) return openRepo(t.dataset.open);
    if (t.dataset.ours !== undefined) { e.stopPropagation(); return resolve(t.dataset.ours, "ours"); }
    if (t.dataset.theirs !== undefined) { e.stopPropagation(); return resolve(t.dataset.theirs, "theirs"); }
    if (t.dataset.diff !== undefined) return showDiff(t.dataset.diff, t.dataset.staged === "true");
    const a = t.dataset.act;
    const map = {
      open: () => openRepo($("#pathInput")?.value.trim()),
      browse: async () => { const p = await pickFolder(); if (p) { if ($("#pathInput")) $("#pathInput").value = p; openRepo(p); } },
      "close-repo": closeRepo,
      branch: () => branchMenu(t.getBoundingClientRect()),
      commit: () => doCommit(false),
      "commit-push": () => doCommit(true),
      push: () => doPush(),
      pull: doPull,
      fetch: doFetch,
      abort: abortMerge,
    };
    if (map[a]) { e.preventDefault(); map[a](); }
  });

  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && state.repo) { e.preventDefault(); doCommit(false); }
  });

  // ============================================================ boot
  async function boot() {
    $("#brandMark").innerHTML = icon("flame", 22);
    $("#settingsBtn").innerHTML = icon("settings", 18);
    $("#themeBtn").innerHTML = icon("moon", 18);
    $("#settingsBtn").onclick = settingsModal;
    $("#themeBtn").onclick = toggleTheme;
    $("#clearActivity").onclick = () => { activity.length = 0; renderActivity(); };
    renderActivity();
    try { state.settings = await call("/settings", {}, "GET"); } catch {}
    applyTheme(state.settings.theme);
    render();
    act("Ready — open a project to begin", "info");
    const recent = state.settings.saved_repos?.[0];
    if (recent) {
      try { const sum = await call("/repo/open", { path: recent.path }); if (sum.is_repo) { state.repo = { path: recent.path, label: base(recent.path) }; await refresh(); } }
      catch {}
    }
  }
  boot();
})();
