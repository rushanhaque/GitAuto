# AutoPush Studio - remove Desktop + Start Menu shortcuts.
$paths = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'AutoPush Studio.lnk'),
    (Join-Path (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs') 'AutoPush Studio.lnk')
)
foreach ($p in $paths) {
    if (Test-Path $p) { Remove-Item $p -Force; Write-Host "  Removed: $p" }
}
Write-Host ''
Write-Host '  Shortcuts removed. Delete this folder to finish uninstalling.'
Write-Host '  To remove the trusted certificate, open certmgr.msc and delete'
Write-Host '  "Rushan Haque" from Trusted Root + Trusted Publishers.'
Write-Host ''
