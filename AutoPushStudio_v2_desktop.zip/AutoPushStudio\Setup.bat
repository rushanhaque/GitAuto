@echo off
title AutoPush Studio Setup
REM One-click setup: trust the publisher certificate and create shortcuts.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
pause
