# AutoPush Studio - one-click setup: trust the publisher + create shortcuts.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe  = Join-Path $here 'AutoPushStudio.exe'
$cer  = Join-Path $here 'AutoPushStudio_publisher.cer'

Write-Host ''
Write-Host '  Setting up AutoPush Studio...' -ForegroundColor Green
Write-Host ''

# 1) Trust the self-signed publisher certificate (Windows shows one prompt).
if (Test-Path $cer) {
    try {
        Import-Certificate -FilePath $cer -CertStoreLocation Cert:\CurrentUser\Root | Out-Null
        Import-Certificate -FilePath $cer -CertStoreLocation Cert:\CurrentUser\TrustedPublisher | Out-Null
        Write-Host '  [1/2] Publisher certificate trusted.'
    } catch {
        Write-Host '  [1/2] Certificate step skipped (you can re-run anytime).' -ForegroundColor Yellow
    }
} else {
    Write-Host '  [1/2] No certificate file found - skipping.' -ForegroundColor Yellow
}

# 2) Create Desktop + Start Menu shortcuts pointing at the app.
$ws = New-Object -ComObject WScript.Shell
$dirs = @(
    [Environment]::GetFolderPath('Desktop'),
    (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs')
)
foreach ($dir in $dirs) {
    $lnk = Join-Path $dir 'AutoPush Studio.lnk'
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath       = $exe
    $s.WorkingDirectory = $here
    $s.IconLocation     = "$exe,0"
    $s.Description       = 'AutoPush Studio - simple Git'
    $s.Save()
}
Write-Host '  [2/2] Shortcuts added to your Desktop and Start menu.'
Write-Host ''
Write-Host '  All set! Launch "AutoPush Studio" from your Desktop or Start menu.' -ForegroundColor Green
Write-Host ''
